<tr noregis='12023-0001' idklaim='1202312023-000110000ABU3' idcpmk='10000ABU3' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3' kdprodi='62201'>
    <td for='namamk' rowspan='10'>1</td>
    <td rowspan='10'>Pendidikan Agama Budha</td>
    <td for='cpmk'>2 aka</td>
    <td for='nilai'>B</td>
    <td for='ref' nodok='' rowspan='10'><a href='http://localhost:8080/uploads/berkas/12023-0001/1675481409_e5526e6a608b6c505781.pdf' target='_blank'><button class='btn btn-sm btn-warning mb-2'>transkirp</button></a><br><a href='http://localhost:8080/uploads/berkas/12023-0001/1675601574_893d807715a98e0f1293.pdf' target='_blank'><button class='btn btn-sm btn-warning mb-2'>kursus</button></a><br></td>
    <td for='tanggapan' rowspan='10'>Ok<br> </td>
    <td for='nilaiAs' rowspan='10'>B</td>
    <td for='kettanggapan' rowspan='10'> asD DAS SADAFD
    </td>
</tr>
<tr idcpmk='10000ABU3' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3'>
    <td for='cpmk' rowspan='2'>2 aka</td>
    <td rowspan='2'>B</td>
</tr>
<tr idcpmk='10000ABU31' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3'>
    <td for='cpmk' rowspan='2'>cmpk 1</td>
    <td rowspan='2'>C</td>
</tr>
<tr idcpmk='10000ABU31' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3'></tr>
<tr idcpmk='10000ABU32' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3'>
    <td for='cpmk' rowspan='2'>cpmk 2</td>
    <td rowspan='2'>K</td>
</tr>
<tr idcpmk='10000ABU32' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3'></tr>
<tr idcpmk='10000ABU33' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3'>
    <td for='cpmk' rowspan='2'>cpmk 3</td>
    <td rowspan='2'>T</td>
</tr>
<tr idcpmk='10000ABU33' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3'></tr>
<tr idcpmk='idpcpmk 2' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3'>
    <td for='cpmk' rowspan='2'>test cpmk</td>
    <td rowspan='2'>B</td>
</tr>
<tr idcpmk='idpcpmk 2' kdmk='10000ABU3' namamk='Pendidikan Agama Budha' sks='3'></tr>
<tr noregis='12023-0001' idklaim='1202312023-000110000AHI3' idcpmk='10000AHI3' kdmk='10000AHI3' namamk='Pendidikan Agama Hindu' sks='3' kdprodi='62201'>
    <td for='namamk' rowspan='8'>2</td>
    <td rowspan='8'>Pendidikan Agama Hindu</td>
    <td for='cpmk'>2</td>
    <td for='nilai'>B</td>
    <td for='ref' nodok='["673448","293825"]' rowspan='8'><a href='http://localhost:8080/uploads/berkas/12023-0001/1675481409_e5526e6a608b6c505781.pdf' target='_blank'><button class='btn btn-sm btn-warning mb-2'>transkirp</button></a><br></td>
    <td for='tanggapan' rowspan='8'>Butuh Tindakan<br><a href='http://localhost:8080/form-tanggapan/10000AHI3'><button class='btn btn-sm btn-success'>Berikan Tanggapan</button></a></td>
    <td for='nilaiAs' rowspan='8'>
    </td>
    <td for='kettanggapan' rowspan='8'> BUTUH JKURSUS
    </td>
</tr>
<tr idcpmk='10000AHI3' kdmk='10000AHI3' namamk='Pendidikan Agama Hindu' sks='3'>
    <td for='cpmk' rowspan='2'>2</td>
    <td rowspan='2'>B</td>
</tr>
<tr idcpmk='10000AHI31' kdmk='10000AHI3' namamk='Pendidikan Agama Hindu' sks='3'>
    <td for='cpmk' rowspan='2'>cpmk 11</td>
    <td rowspan='2'>B</td>
</tr>
<tr idcpmk='10000AHI31' kdmk='10000AHI3' namamk='Pendidikan Agama Hindu' sks='3'></tr>
<tr idcpmk='10000AHI32' kdmk='10000AHI3' namamk='Pendidikan Agama Hindu' sks='3'>
    <td for='cpmk' rowspan='2'>cpmk 22</td>
    <td rowspan='2'>C</td>
</tr>
<tr idcpmk='10000AHI32' kdmk='10000AHI3' namamk='Pendidikan Agama Hindu' sks='3'></tr>
<tr idcpmk='10000AHI33' kdmk='10000AHI3' namamk='Pendidikan Agama Hindu' sks='3'>
    <td for='cpmk' rowspan='2'>cpmk 33</td>
    <td rowspan='2'>T</td>
</tr>
<tr idcpmk='10000AHI33' kdmk='10000AHI3' namamk='Pendidikan Agama Hindu' sks='3'></tr>