<meta charset="utf-8" />
<title><?= $title ? lang('Files.' . $title . '') : '' ?> | UNIFA</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="SILAJU" name="description" />
<meta content="Registrasn Program Rekognisi Pembelajaran Lampau Universitas Fajar" name="description" />
<meta content="Registrasn Program Rekognisi Pembelajaran Lampau" name="description" />
<meta content="Registrasn RPL" name="description" />
<meta content="UNIFA" name="author" />
<!-- App favicon -->
<link rel="shortcut icon" href="/assets/images/logo-light.png">